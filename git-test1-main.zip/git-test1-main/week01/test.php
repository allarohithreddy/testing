<?php
    echo 7 * 9;
?>

